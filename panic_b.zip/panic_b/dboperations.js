var config = require('./dbconfig');
const sql = require('mssql');


//get-Panic-Buttons target
//obtiene la  informacion que ir[a dentro de la tarjeta,
//es decir, los detalles del evento, los detalles de conductor
//y los detalles del vahiculo que lo detono
async function getCurrentPanicButtonsMix() {
    try {
        const created_at = new Date().toLocaleString()
        console.log(created_at)
        console.log(typeof(created_at))
        let pool = await sql.connect(config);
        let panic_B = await pool.request()
        .input('currentDate', created_at)
        .query(` SELECT TOP (100) pb.id as panic_b_id
                        ,pb.id as event_id
                        ,pb.created_at AS event_date
                        ,a.fleet_number AS eco
                        ,latitude
                        ,longitude
                        ,D.name
                        ,pb.driver_id
                        ,speed
                        ,location AS Origen
                        ,proveedor
                        ,status
                        ,validation as validation
                        ,aditional_comments as comentarios
                        ,CONCAT(registration_number, ' - ', fleet_number, ' - ', asset_region, ' ', asset_agency, ' ', brand, ' ', model) AS assetDescription
                FROM [prd02churchill].[dbo].[mix_panic_button]  pb
                INNER JOIN prd02churchill..mix_mt_drivers d
                on d.mix_driver_id =pb.driver_id
                INNER JOIN prd02churchill..mix_mt_assets a
                on a.mix_asset_id = pb.asset_id
                ORDER BY panic_b_id DESC;`);
        return panic_B.recordsets;
    }//en caso de error mandar el mensaje de error
    catch (error) {
        console.log(error);
    }
}

//actualizacion de infromacion de un registro de botones de panico

async function postUpdateStatusPanicButton() {
    try {
        const created_at = new Date().toLocaleString()
        let pool = await sql.connect(config);
        let cctv_events = await pool.request()
        //estas variables se ingresaran desde el frontend con el nombre 
        //que no lleva las comillas
        .input('statusId', statusId)
        .input('realFake', realFake)
        .input('coments', coments)
        .input('created_at', created_at)
        .input('panic_b_id', panic_b_id)
        .query(`UPDATE [prd01churchill]..[mix_panic_button]
                SET   status = @statusId,
                    real_fake = @realFake,
                    aditional_comments = @coments,
                    updated_at =@created_at
                WHERE mix_panic_button.id = @panic_b_id
        ;`);
        return cctv_events.recordsets;
    }//en caso de error mandar el mensaje de error
    catch (error) {
        console.log(error);
    }
}


//funcion asicrona
//obtener los botones de panico de smartracker
//todos sus datos de boton de panico son con id 8

async function getCurrentPanicButtonsSMT() {
    try {
        //declaramos variables y conexiones
        const created_at = new Date().toLocaleString()
        console.log(created_at)
        console.log(typeof(created_at))
        let pool = await sql.connect(config);
        let panic_B_smt = await pool.request()
        .input('currentDate', created_at)
        .query(`SELECT TOP (500) 
                 asset_id
                ,id
                ,provider
                ,event_name
                ,event_date
                ,context
                ,asset_id
                ,created_at
            FROM prd01churchill..rep_gen_event_entry WHERE global_event_id = 8 
            order by id desc 
        ;`);
        return panic_B_smt.recordsets;
    }//en caso de error mandar el mensaje de error
    catch (error) {
        console.log(error);
    }
} 


//nombre de la consulta que ejecutara cada api
module.exports = {
    
    getCurrentPanicButtonsMix:getCurrentPanicButtonsMix,
    postUpdateStatusPanicButton:postUpdateStatusPanicButton,
    getCurrentPanicButtonsSMT:getCurrentPanicButtonsSMT
}