const config = {
    user: 'sa',
    password: 'Administraciondeflotas2020!$',
    server: '10.0.100.5', // You can use 'localhost\\instance' to connect to named instance
    database: 'prd01churchill',
    options:{
        trustedconnection: true,
        enableArithAbort : true, 
        instancename :'CHURCHILL04'
    },
}

module.exports = config; 