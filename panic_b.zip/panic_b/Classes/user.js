class User{
    constructor(Name,LastName,Email,PhoneNumber,EmployeeNumber){
        this.Name = Name; 
        this.LastName = LastName; 
        this.Email = Email;
        this.PhoneNumber = PhoneNumber;
        this.EmployeeNumber = EmployeeNumber; 
    }
}

module.exports = User;