/* Este script crea las ligas del api para su consumo
cada ruta consume informacion directa de la base de datos */ 


var Db  = require('./dboperations');
var User = require('./Classes/user');
const dboperations = require('./dboperations');

var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors');
var app = express();
var router = express.Router();


//decidimos la estructura del response del API (en este caso un json)
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
//definimos la ruta en la liga
app.use('/api/PanicButtons', router);



//por medidas de seguridad apicamos un middleware para hacer mas segura la consulta
router.use((request,response,next)=>{
    console.log('middleware');
    next();
 })

    //Get Panic Buttons
    router.route('/getCurrentPanicButtonsMix').get((request,response)=>{
    dboperations.getCurrentPanicButtonsMix().then(result => {
        console.log(result)
        response.json(result[0]);
        })
    })
    //update the panic button event
    router.route('/postUpdateStatusPanicButton').get((request,response)=>{
    dboperations.postUpdateStatusPanicButton().then(result => {
        console.log(result)
        response.json(result[0]);
        })
    })
    // get the smt panic buttons pressed    
    router.route('/getCurrentPanicButtonsSMT').get((request,response)=>{
        dboperations.getCurrentPanicButtonsSMT().then(result => {
            console.log(result)
            response.json(result[0]);
            })
        }) 
    



 //declaramos que cada api correra en el puerto 8097
var port = process.env.PORT || 8097;
app.listen(port);
 //dentro de consola veremos laleyenda
console.log('panic_b API is running in port:  ' + port);